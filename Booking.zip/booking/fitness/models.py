from django.db import models

# Create your models here.

class fitness_classes(models.Model):
    
    class_name = models.CharField(max_length=100)
    date_time = models.DateTimeField()
    instructor = models.CharField(max_length=100)
    solts = models.PositiveIntegerField()
    
class Booking(models.Model):
    
    Booking_class_name = models.CharField(max_length=100)
    client_name = models.CharField(max_length=100)
    client_email = models.EmailField()
    booked_solt = models.DateTimeField()
    