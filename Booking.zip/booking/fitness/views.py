from django.shortcuts import render
from .models import fitness_classes , Booking
from datetime import datetime , timedelta
from django.shortcuts import render , get_object_or_404

def home(request):
    
    today = datetime.now().date()
    now_hour = datetime.now().time().hour
    
    today_class = fitness_classes.objects.filter(date_time__date = today)
    
    class_list = []
    
    for cls in today_class:
        
        class_hour = cls.date_time.time().hour
        
        if now_hour < class_hour:
            class_list.append(cls)
        else:
            next_day = today + timedelta(days=1)
            next_class = fitness_classes.objects.filter(date_time__date = next_day , class_name = cls.class_name).first()
            if next_class:
                class_list.append(next_class)
                
    class_list.sort(key=lambda cls: cls.date_time) 
    
    return render(request , 'booking_class.html',{'classes':class_list})

def register_class(request , class_id):
    
    cls = get_object_or_404(fitness_classes,id = class_id)
    
    if request.method == 'POST':
        
        name = request.POST.get('name')
        email = request.POST.get('email')
        
        if cls.solts <= 0:
            return render(request, 'register_class.html', {
                'cls': cls,
                'error': 'No slots available for this class.'
            })
            
        already_booked = Booking.objects.filter(
            Booking_class_name = cls.class_name,
            client_email = email,
            booked_solt = cls.date_time
        ).exists()
        
        if already_booked:
            return render(request, 'register_class.html', {
                'cls': cls,
                'error': 'You have already registered for this class with this email.'
            })
            
        Booking.objects.create(
            Booking_class_name = cls.class_name,
            client_name = name,
            client_email = email,
            booked_solt = cls.date_time
        )
        cls.solts -= 1
        cls.save()
        
        return render(request, 'success.html', {
            'cls': cls,
            'name': name
        })
    
    return render(request , 'register_class.html' , {'cls':cls})

def booking_data(request):

    email = request.GET.get('email')
    bookings = []

    if email:
        bookings = Booking.objects.filter(client_email=email).order_by('booked_solt')

    return render(request, 'user_booking.html', {
        'email': email,
        'bookings': bookings
    })
    