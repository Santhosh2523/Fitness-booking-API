import os
import django
from datetime import datetime , timedelta , time

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'booking.settings')
django.setup()

from fitness.models import fitness_classes

current_time = datetime.now().date()

class_schedule = {
    'YOGA':time(6,0),
    'ZUMBA':time(8,0),
    'HIIT':time(18,0)
}
instructor = {
    'YOGA':'sandy',
    'ZUMBA':'suresh',
    'HIIT':'sankar'
}

for i in range(90):
    
    day = current_time + timedelta(days=i)
    
    for name , class_time in class_schedule.items():
        dt = datetime.combine(day , class_time)
        
        if not fitness_classes.objects.filter(class_name = name , date_time =dt).exists():
            fitness_classes.objects.create(
                class_name = name,
                date_time = dt,
                instructor = instructor[name],
                solts = 5
            )
            print(f"✅ Created {name} on {dt.strftime('%d-%m-%Y %I:%M %p')}")
        else:
            print(f"⚠️ Already exists: {name} on {dt.strftime('%d-%m-%Y %I:%M %p')}")
            